import os
if not os.path.exists(r'str.txt'):
    print("no file to read")
    exit()
file_strings = []

with open(r'str.txt') as str_file:
    file_strings = str_file.readlines()

word_count = []

for ind, el in enumerate(file_strings):
    word_count = el.split()
    print(f"в {ind+1}-й строке количество слов: {len(word_count)}")
