import os
import json
if not os.path.exists(r'firm_list'):
    print("no file to read")
    exit()

new_list = []
with open(r'firm_list') as str_file:
    firm_str = str_file.readlines()

firm_dict = {}
av_prof_dict = {}
profit = 0
firm_plus = 0
avar_profit = 0
for el in firm_str:
    firm_param = el.split()
    for i in firm_param:
        firm_dict.update({firm_param[0]: int(firm_param[2])-int(firm_param[3])})
for n in firm_dict.values():
    if n > 0:
        profit += n
        firm_plus+=1

av_prof_dict.update({'avarage_profit': round(profit/firm_plus)})

new_list = [firm_dict, av_prof_dict]
print(new_list)

with open("new_file.json", "w") as write_f:
    json.dump(new_list, write_f)