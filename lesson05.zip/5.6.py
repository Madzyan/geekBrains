import os
if not os.path.exists(r'lessons'):
    print("no file to read")
    exit()

with open(r'lessons') as str_file:
    lessons_str = str_file.readlines()
lesson_dict = {}
for el in lessons_str:
    tmp = el.replace(':', '')
    words = tmp.split()
    sum_hours = 0
    for idx, tmp_hours in enumerate(words):
        if idx != 0 and tmp_hours != '—':
            hours = ''
            for i in tmp_hours:
                if i == "(":
                    break
                else:
                    hours = hours + i
            sum_hours += int(hours)
            lesson_dict.update({words[0]: sum_hours})

print(lesson_dict)


