import os

if not os.path.exists(r'empl.txt'):
    print("no file to read")
    exit()

with open(r'empl.txt') as str_file:
    empl_strings = str_file.readlines()

word_count = []
losers = []
sum_sal = 0
for el in empl_strings:
    word_count = el.split()
    sum_sal = sum_sal + float(word_count[1])
    if float(word_count[1]) < 20000:
        losers.append(word_count[0])

if len(losers):
    print("сотрудники с зарплатой менее 20 000.00:")
    for el in losers:
        print(el)

print(f"\nСредняя зарплата {round(sum_sal / len(empl_strings), 2)}")
