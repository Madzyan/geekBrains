import os
from random import randint
new_file = open(r'num.txt', mode="w")

new_list = [randint(0, 99) for el in range(20)]
file_str = ' '.join(str(el) for el in new_list)

print(file_str, file=new_file)
new_file.close()


if not os.path.exists(r'num.txt'):
    print("no file to read")
    exit()

with open(r'num.txt') as str_file:
    num_str = str_file.readline()

num_list = num_str.split()

print(sum(int(el) for el in num_list))


