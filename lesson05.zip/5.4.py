import os
if not os.path.exists(r'eng.txt'):
    print("no file to read")
    exit()

eng_dict = {'One': 'Один', 'Two': 'Два', 'Three': 'Три', 'Four': 'Четыре'}

with open(r'eng.txt') as str_file:
    eng_strings = str_file.readlines()

ru_strings = []

for el in eng_strings:
    words = el.split()
    words[0] = eng_dict.get(words[0])
    ru_str = ' '.join(i for i in words)
    ru_strings.append(ru_str)

new_file = open(r'ru.txt', mode="a")
for el in ru_strings:
    print(el, file=new_file)
new_file.close()
