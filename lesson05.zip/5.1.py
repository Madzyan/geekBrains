new_file = open(r'str.txt', mode="a")

user_str = ""

if new_file.writable():
    while True:
        user_str = input("строка для записи в файл\n>>>")
        if user_str == "":
            break
        new_file.write(user_str + "\n")
else:
    print("ERORR")
new_file.close()
