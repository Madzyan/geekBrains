class Cell:
    def __init__(self, units):
        self.units = units

    def __add__(self, other):
        return Cell(self.units + other.units)

    def __sub__(self, other):
        if self.units - other.units < 0:
            return f"вычетание невозможно"
        else:
            return Cell(self.units - other.units)

    def __mul__(self, other):
        return Cell(self.units * other.units)

    def __truediv__(self, other):
        return Cell(self.units // other.units)

    def __str__(self):
        return str(self.units)

    def make_order(self, units_per_line):
        result = ""
        lines = self.units // units_per_line
        tail = self.units % units_per_line
        for i in range(lines):
            result += "*" * units_per_line + "\\n"
        result += "*" * tail
        if result == "":
            result = "0"
        return result


units_1 = input("ячеек в клетке 1\n>>>")
units_2 = input("ячеек в клетке 2\n>>>")
cell_1 = Cell(int(units_1))
cell_2 = Cell(int(units_2))

if isinstance(cell_1, Cell) and isinstance(cell_2, Cell):
    cell_3 = cell_1 + cell_2
    print(f"сложение: {cell_3.make_order(3)}")
    cell_3 = cell_1 - cell_2
    if isinstance(cell_3, Cell):
        print(f"вычитание: {cell_3.make_order(3)}")
    else:
        print(cell_1 - cell_2)
    cell_3 = cell_1 * cell_2
    print(f"умножение: {cell_3.make_order(3)}")
    cell_3 = cell_1 / cell_2
    print(f"деление: {cell_3.make_order(3)}")
