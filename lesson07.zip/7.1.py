class Matrix:
    def __init__(self, matr):
        self.matr = matr

    def __str__(self):
        self.m = ""
        for tmp_str in self.matr:
            tmp_str = str(tmp_str) + "\n"
            self.m = self.m + tmp_str
        return f"матрица\n{self.m}"

    def sum_list(self, list1, list2):
        list = []
        for j in range(len(list1)):
            list.append(list1[j] + list2[j])
        return list

    def __add__(self, other):
        tmp_matr = []
        for i in range(len(self.matr)):
            tmp_matr.append(self.sum_list(self.matr[i], other.matr[i]))
        return Matrix(tmp_matr)


mc_1 = Matrix([[1, 2, 3], [30, 40, 23], [34, 62, 98]])
mc_2 = Matrix([[4, 5, 6], [10, 20, 34], [65, 35, 34]])

print(mc_1)
print(mc_2)
print(mc_1 + mc_2)
