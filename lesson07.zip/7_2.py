from abc import ABC, abstractmethod


class Clothes(ABC):
    @abstractmethod
    def cloth_per_unit(self):
        pass


class Coat(Clothes):

    def __init__(self, size):
        self.v = size

    @property
    def cloth_per_unit(self):
        sqr = self.v / 6.5 + 0.5
        return round(sqr, 2)


class Suit(Clothes):
    def __init__(self, size):
        self.h = size

    @property
    def cloth_per_unit(self):
        sqr = self.h * 2 + 0.3
        return round(sqr, 2)


coat = Coat(48)
suit = Suit(1.9)

# print(coat.cloth_per_unit)
# print(suit.cloth_per_unit)

coat_amount = 15
suit_amount = 23

print(f"На пальто нужно {coat.cloth_per_unit * coat_amount} ткани")
print(f"На костюмы нужно {suit.cloth_per_unit * suit_amount} ткани")
