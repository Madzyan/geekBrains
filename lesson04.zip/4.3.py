
new_list = [el for el in range(20, 240) if (el % 21 == 0) or (el % 20 == 0)]
print(new_list)
