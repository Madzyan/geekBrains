from itertools import cycle

lst = [3, 5, 7]
i = 0
for el in cycle(lst):
    if i > 10:
        exit()
    print(el)
    i += 1
