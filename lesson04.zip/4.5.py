from functools import reduce


new_list = [el for el in range(100, 1001) if el % 2 == 0]


def mult_func(var1, var2):
    return var1*var2


print(reduce(mult_func, new_list))
print(new_list)
