from random import randint

new_list = [randint(1, 99) for el in range(10)]
i = 1
selected_list = []

while i < len(new_list):
    if new_list[i] > new_list[i-1]:
        selected_list.append(new_list[i])
    i += 1

print(new_list)
print(selected_list)
