from random import randint
new_list = [randint(1, 9) for el in range(9)]
selected_list = [el for el in new_list if new_list.count(el) == 1]
print(new_list)
print(selected_list)
