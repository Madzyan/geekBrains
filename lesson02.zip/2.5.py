rate_list = [78, 45, 45, 25, 5, 5, 4]
print(rate_list)
new_el = int(input("введите новый элемент рейтинга (натуральное число)\n>>>"))
i = int(0)
for i in range(len(rate_list)):
    if new_el > int(rate_list[i]):
        rate_list.insert(i, new_el)
        break
    if i == len(rate_list)-1:
        rate_list.append(new_el)
        break
print(rate_list)
