new_list = ['зима', 'зима', 'весна', 'весна', 'весна', 'лето', 'лето', 'лето', 'осень', 'осень', 'осень', 'зима']
new_dict = {1: 'зима',  2: 'зима', 12: 'зима',
            3: 'весна', 4: 'весна', 5: 'весна',
            6: 'лето', 7: 'лето', 8: 'лето',
            9: 'осень', 10: 'осень', 11: 'осень'}
while True:
    user_month = input('введите месяц от 0 до 12\n>>>')
    if user_month.isnumeric():
        if int(user_month) < 13 and int(user_month) > 0:
            print(new_list[int(user_month) - 1])
            print(new_dict.get(int(user_month)))
            break



