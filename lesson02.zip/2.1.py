new_list = [5, 8.3, "text", b'bytes', True, {1, 2, 3}, [4, 5, 6], (7, 8, 9), None, dict(s=123, n=456)]
print("new_list =", new_list, end=" ")
print(type(new_list))
for el in new_list:
    print("el =", el, end=" ")
    print(type(el))
