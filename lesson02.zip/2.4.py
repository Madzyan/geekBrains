word_list = []
str = input('введите строку\n>>>')
word_list = str.split()
#print(word_list)
for ind, el in enumerate(word_list):
    if len(el) > 10:
        tmp = el[0:10]
        el = tmp
    print(ind, el)