input_cont = 'y'
new_list = []
while input_cont == 'y':
    new_list.append(input("введите элемент массива\n>>>"))
    input_cont = input("продолжить вводить?(y/n)\n>>>")
    if input_cont == "n":
        break
    elif input_cont == "y":
        continue
    else:
        input_cont = input("продолжить вводить?(y/n)\n>>>")
print(new_list)
if (len(new_list) // 2) == 0:
    list_len = len(new_list) - 1
else:
    list_len = len(new_list)
i = 0
while i < list_len-1:
    tmp = new_list[i]
    new_list[i] = new_list[i+1]
    new_list[i+1] = tmp
    i = i+2
print(new_list)

