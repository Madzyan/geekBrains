user_num = input("введите число от 0 до 9")
a = int(user_num)
b = int(user_num+user_num)
c = int(user_num+user_num+user_num)
s = a + b + c
print(f"{a} + {b} + {c} = {s}")
