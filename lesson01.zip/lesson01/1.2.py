user_sec = int(input("введите количество секунд для перевода в минуты и часы"))
hh = user_sec // 3600
mm = (user_sec % 3600) // 60
ss = (user_sec % 3600) % 60
print(f"получится {hh}:{mm}:{ss}")
