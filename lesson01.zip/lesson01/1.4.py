user_str = input("введите число")
l_num = list(user_str)
counter = len(user_str) - 1
max_num = (l_num[counter])
while counter > 0:
    counter = counter - 1
    if max_num < l_num[counter]:
        max_num = l_num[counter]
print(max_num)
