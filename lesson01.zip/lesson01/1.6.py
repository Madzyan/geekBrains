start = int(input("начальный результат"))
goal = int(input("конечный результат"))
int_res = start
day_counter = 1
print(f"{day_counter}-й день: {int_res}")
while int_res < goal:
    int_res = int_res * 1.1
    day_counter = day_counter+1
    print(f"{day_counter}-й день:", "%.2f" % int_res)
