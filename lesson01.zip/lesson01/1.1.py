a = 31
b = 12
c = a * b
print(f"{a} * {b} = {c}")
hello_str = input("print 'Hello, world' or something else \n")
print(hello_str)
