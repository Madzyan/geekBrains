class Complex_num:
    real_a: int
    real_b: int

    def __init__(self, real_a, real_b):
        self.real_a = real_a
        self.real_b = real_b

    def __add__(self, other):
        return Complex_num(self.real_a + other.real_a, self.real_b + other.real_b)

    def __str__(self):
        return f'{self.real_a} + {self.real_b}i'

    def __mul__(self, other):
        return Complex_num(self.real_a * other.real_a - self.real_b * other.real_b,
                           self.real_a * other.real_b + self.real_b * other.real_a)


z1 = Complex_num(15, 23)
z2 = Complex_num(4, 6)

print(z1)
print(z1 + z2)
print(z1 * z2)
