class Data:
    test_data_str: str

    def __init__(self, data_str):
        self.data_str = data_str

    @staticmethod
    def data_splitter(data_str: str):
        data_list = data_str.split('-')
        return data_list

    @classmethod
    def str_to_int(cls, data_str):
        data_list_str = cls.data_splitter(data_str)
        data_list_int = []
        for el in data_list_str:
            data_list_int.append(int(el))
        return data_list_int

    @staticmethod
    def data_valid(data_list):
        if data_list[0] in range(1, 32) and data_list[1] in range(1, 13) and data_list[2] > 0:
            print("valid")
        else:
            print('not valid data')


test_data_str = "23-11-2002"
print(Data.str_to_int(test_data_str))
data_l = Data.str_to_int(test_data_str)
print(type(data_l[1]))
Data.data_valid(Data.str_to_int(test_data_str))
