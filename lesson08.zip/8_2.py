class Div_by_zero(Exception):
    def __init__(self, divisor):
        self.divisor = divisor

    def __str__(self):
        return f"division by zero"

def division(var1, var2):
    if var2 == 0:
        raise Div_by_zero(var2)
    result = var1/var2
    print(result)

var1 = int(input("введите делимое\n>>>"))
var2 = int(input("введите делитель\n>>>"))
try:
    division(var1, var2)
except Div_by_zero as exception:
    print("на ноль делить нельзя")
