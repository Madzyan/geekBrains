class NotDigital(Exception):
    def __str__(self):
        return f"не число"


def digit_valid(new_str):
    if not new_str.isdigit():
        raise NotDigital
        print("bad")
        digit_str = False
    else:
        digit_str = True
    return digit_str


def new_func():
    num_list = []
    user_str = ''
    while True:
        user_str = input("введите число или 'stop' для остановки\n>>>")
        if user_str == 'stop':
            break
        else:
            try:
                digit_valid(user_str)
            except NotDigital as exception:
                print("не является числом")
                continue
            num_list.append(user_str)
    return num_list


print(new_func())
