class Stock:
    capacity: int
    equip_in_stock: int
    def __init__(self, capacity, equip_in_stock):
        self.capacity = capacity
        self.equip_in_stock = equip_in_stock

class OfficeEquipment:
    work_condition: bool
    title: str
    departament: str

    def __init__(self, title, work_condition, departament):
        self.title = title
        self.work_condition = work_condition
        self.departament = departament

    def equip_moving(self, department):
        print(f"оборудования перенесено из отдела {self.departament} в {department}")
        self.departament = department

class Printer(OfficeEquipment):
    color: bool

    def __init__(self, title, work_condition, departament, color):
        super().__init__(title, work_condition, departament)
        self.color = color


    def __str__(self):
        return f'Принтер {self.title}, работает: {self.work_condition}, находится в отделе {self.departament}, цветной: {self.color}'

class Scanner(OfficeEquipment):
    pixels: int

    def __init__(self, title, work_condition, departament, pixels):
        super().__init__(title, work_condition, departament)
        self.pixels = pixels

    def __str__(self):
        return f'Сканер {self.title}, работает: {self.work_condition}, находится в отделе {self.departament}, разрешение(пикселей) : {self.pixels}'

class Mfu(OfficeEquipment):
    sheets_per_minute: int

    def __init__(self, title, work_condition, departament, sheets_per_minute):
        super().__init__(title, work_condition, departament)
        self.sheets_per_minute = sheets_per_minute

    def __str__(self):
        return f'МФУ {self.title}, работает: {self.work_condition}, находится в отделе {self.departament}, скорость копирования: {self.sheets_per_minute}'


prn1 = Printer("PH", True, "Secretariat", True)
scn1 = Scanner("Conan", True, "Secretariat", 4000)
mfu1 = Mfu("Xer", False, "Secretariat", 30)
total_eq = [prn1, scn1, mfu1]
stock = Stock(2, 0)

while True:
    print("Управление оборудованием:\n '1' - все оборудование, '2' - перенести на склад, '3' -  взять со склада, 'q' - выйти")
    action = input("следующее действие\n>>>")
    if action == "q":
        print("завершение работы")
        break
    elif action == "1":
        for el in total_eq:
            print(f"{el}")
    elif action == "2":
        if stock.equip_in_stock == stock.capacity:
            print("склад забит")
            continue
        tmp = input("что перенести на склад? '1' - принтер, '2' - сканер, '3' - МФУ")
        if tmp == "1":
            if prn1.departament == "stock":
                print("принтер уже там")
                continue
            prn1.equip_moving("stock")
            stock.equip_in_stock += 1
        elif tmp == "2":
            if scn1.departament == "stock":
                print("сканер уже там")
                continue
            scn1.equip_moving("stock")
            stock.equip_in_stock += 1
        elif tmp == "3":
            if prn1.departament == "stock":
                print("МФУ уже там")
                continue
            mfu1.equip_moving("stock")
            stock.equip_in_stock += 1
        print(f"сводных мест на складе {stock.capacity - stock.equip_in_stock}")
    elif action == "3":
        tmp = input("что взять со склада? '1' - принтер, '2' - сканер, '3' - МФУ")
        if tmp == "1":
            if prn1.departament == "Secretariat":
                print("принтер уже взят")
                continue
            prn1.equip_moving("Secretariat")
            stock.equip_in_stock -= 1
        if tmp == "2":
            if scn1.departament == "Secretariat":
                print("сканер уже взят")
                continue
            prn1.equip_moving("Secretariat")
            stock.equip_in_stock -= 1
        if tmp == "3":
            if prn1.departament == "Secretariat":
                print("МФУ уже взят")
                continue
            mfu1.equip_moving("Secretariat")
            stock.equip_in_stock -= 1

    else:
        print("введите правильно команду")
