name = "Ivan"
surname = "Po"
birth = "11.11.1900"
city = "NY"
email = "i_po@123.com"
phone_num = "1(234)1234578"


def person_print(name, surn, bir, city, email, tel):
    return name, surn, bir, city, email, tel


print(person_print(name=name, surn=surname, bir=birth, city=city, email=email, tel=phone_num))
