a = 11
b = 8
c = 44


def my_func(var1, var2, var3):
    l = [var1, var2, var3]
    tmp1 = max(l)
    l.remove(tmp1)
    tmp2 = max(l)
    sum = tmp1 + tmp2
    return sum


print(my_func(a, b, c))
