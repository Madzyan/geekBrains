def int_func (user_str):
    user_str = user_str.capitalize()
    return user_str

new_str=""
user_str = input("введите строку\n>>>")
user_str_list = user_str.split()
for user_word in user_str_list:
    user_word = int_func(user_word)
    new_str = new_str + user_word + " "

print(new_str)