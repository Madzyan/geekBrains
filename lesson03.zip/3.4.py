x = 4
y = -3


def my_func(x, y):
    var1 = x**y
    tmp = x
    for n in range(abs(y)-1):
        tmp = tmp*x
    var2 = 1/tmp
    return var1, var2


print(my_func(x, y))
