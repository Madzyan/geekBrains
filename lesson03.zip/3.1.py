a = int(input("введите делимое\n>>>"))
b = int(input("введите делитель\n>>>"))


def divis(div_1, div_2):
    try:
        return div_1 / div_2
    except ZeroDivisionError:
        return "на ноль делить нельзя"


print(divis(a, b))
