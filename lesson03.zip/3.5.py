summ = 0
count = 0
quit_chr = "q"

while count == 0:
    user_str = input("введите числа(для выхода q)\n>>>")
    for el in user_str:
        if el == quit_chr:
            count = 1
            user_str = ''.join(i for i in user_str if not i in quit_chr)

    numb_list = user_str.split()
    for tmp in numb_list:
        summ = summ + int(tmp)
    print(summ)

