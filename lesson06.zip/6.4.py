import random
class Car:
    speed: int
    color: str
    name: str
    is_police: bool

    def __init__(self, speed, color, name, is_police):
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police

    def go(self):
        print(f"машина едет")

    def stop(self):
        print(f"машина остановилась")

    def turn_right(self):
        print("машина повернула направо")

    def turn_left(self):
        print("машина повернула налево")

    def show_speed(self):
        speed = random.randint(50, 100)
        return speed

class TownCar(Car):
    speed: int
    color: str
    name: str
    is_police = False
    purpose: str

    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police
        self.purpose = "town_ride"
    def car_info(self):
        print(f"скорость: {self.speed}, цвет: {self.color}, название: {self.name}, использование: {self.purpose}")

    def show_speed(self):
        speed = speed = random.randint(40, 100)
        if speed > 60:
            print("корость превышена")
        return speed

class SportCar(Car):
    speed: int
    color: str
    name: str
    is_police = False
    purpose: str

    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police
        self.purpose = "speed_ride"

    def car_info(self):
        print(f"скорость: {self.speed}, цвет: {self.color},название: {self.name}, использование: {self.purpose}")

class WorkCar(Car):
    speed: int
    color: str
    name: str
    is_police = False
    purpose: str

    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police
        self.purpose = "work_ride"

    def car_info(self):
        print(f"скорость: {self.speed}, цвет: {self.color},название: {self.name}, использование: {self.purpose}")

    def show_speed(self):
        speed = speed = random.randint(20, 60)
        if speed > 40:
            print("корость превышена")
        return speed

class PoliceCar(Car):
    speed: int
    color: str
    name: str
    is_police = True
    purpose: str

    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police
        self.purpose = "pursuit"

    def car_info(self):
        print(f"скорость: {self.speed}, цвет: {self.color},название: {self.name}, использование: {self.purpose}")


car_choice = input("выбор авто: '1'-TownCar, '2'-SportCar, '3'-WorkCar, '4'-PoliceCar\n>>>")
if car_choice == "1":
    car = TownCar(56, "blue", "opel", False)
elif car_choice == "2":
    car = SportCar(68, "red", "gt", False)
elif car_choice == "3":
    car = WorkCar(59, "black", "tatra", False)
elif car_choice == "4":
    car = PoliceCar(150, "black", "tatra", False)
else:
    exit()

car.car_info()


drive = ""

while True:
    print("Управление: 'g' - ехать, 's' - остановиться, 'r' -  направо, 'l' - налево, 'q' - выйти")
    drive = input("следующее действие\n>>>")
    if drive == "q":
        print("выходим из машины")
        break
    elif drive == "g":
        car.go()
        print(f"текущая скорость: {car.show_speed()}")
    elif drive == "s":
        car.stop()
    elif drive == "r":
        car.turn_right()
    elif drive == "l":
        car.turn_left()
    else:
        print("введите правильно команду")
