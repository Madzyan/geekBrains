import time, os
class TrafficLight:
    __color = ['red ', 'yellow', 'green ']

    def running (self):
#        stop = ""
        print(f"{TrafficLight.__color[0]}", end='')
        time.sleep(7)
#        os.system('clear')
        print(f"\r{TrafficLight.__color[1]}", end='')
        time.sleep(2)
        print(f"\r{TrafficLight.__color[2]}", end='')
        time.sleep(2)


tr_l = TrafficLight()
tr_l.running()
