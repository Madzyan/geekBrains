class Road:

    _length: int
    _width: int

    mass_1sm: float
    thickness: float

    def __init__(self, length, width):
        self._length = length
        self._width = width

    def mass_of_asph(self, m, t):
        self.mass_1sm = m
        self.thickness = t
        return round(self.mass_1sm*self.thickness*self._width*self._length)


road_1 = Road(100, 15)


print(f"Нужно {road_1.mass_of_asph(0.025, 5)} тонн асфальта")
