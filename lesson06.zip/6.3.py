class Worker:
    name: str
    surname: str
    position: str
    _income = {}
    wage: float
    bonus: float

    def __init__(self, name, surname, position, wage, bonus):
        self.name = name
        self.surname = surname
        self.position = position
#        self.wage = wage
#        self.bonus = bonus
        self._income = {"wage": wage, "bonus": bonus}

class Position(Worker):
    def __init__(self, name, surname, position, wage, bonus):
        super().__init__(name, surname, position, wage, bonus)

    def get_full_name (self):
        return f"{self.name} {self.surname}"

    def get_total_income(self):
        return sum(self._income.values())



fed_dof = Position("Fed", "Dof", "gardener", 50000, 15000)


print(f"Полное имя {fed_dof.get_full_name()}")
print(f"Доход с учетом премии {fed_dof.get_total_income()}")



