class Stationery:
    title: str

    def __init__(self, title):
        self.title = title

    def draw(self):
        print("Запуск отрисовки")

p=Stationery("п")
p.draw()

class Pen(Stationery):
    title: str
    color: str

    def __init__(self, title, color):
        super().__init__(title)
        self.color = color

    def draw(self):
        print(f"{self.title}, цвет {self.color}")

p=Pen("ручка", "синий")
p.draw()

class Pencil(Stationery):
    title: str
    color: str

    def __init__(self, title, color):
        super().__init__(title)
        self.color = color

    def draw(self):
        print(f"{self.title}, цвет {self.color}")

pencil = Pencil("карандаш", "зеленый")
pencil.draw()

class Handle(Stationery):
    title: str
    color: str

    def __init__(self, title, color):
        super().__init__(title)
        self.color = color

    def draw(self):
        print(f"{self.title}, цвет {self.color}")

mark = Handle("маркер", "желтый")
mark.draw()
